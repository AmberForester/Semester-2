package quiz1;

public class Node {
    int data;
    Node pointer;

    public Node() {}

    public Node(int data) {
        this.data = data;
        this.pointer = null;
    }
}
