package UapPbo2023;

public interface Perawatan {
    
    void treatment();
}
