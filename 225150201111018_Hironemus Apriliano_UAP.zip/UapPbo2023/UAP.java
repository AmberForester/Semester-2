package UapPbo2023;

public class UAP {
    public static void main(String[] args) {
        Data.mulai();
        Data.info();
    }
}
